package kr.co.tj.apigatewayservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApigatewayServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
